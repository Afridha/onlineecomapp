export class Customer {
    custName : string;
    custEmail : string;
    custMobile : string;
    custPassword : string;
    constructor(){
        
    }
}