export class Product {
    id : number;
    title : string;
    type : string;
    weight : number;
    productType : string;
    brand : string;
    price : number;

    constructor() {
        
    }
}