export class Contact {
    email:string;
    mobileNo:string;
    comments:string;
    constructor(){

    }
}