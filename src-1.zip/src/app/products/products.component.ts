import { Component, OnInit } from '@angular/core';
import { MockData } from '../mock-product-data';
import { Product } from '../models/product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  //creating an product array
  products : Product [] = [];
  constructor(public productService : ProductService) {
    //copying the mockdata in to the products array
    //this.products = MockData.Products;
    //this.products = productService.getProducts();
    console.log(this.products);
  }

  ngOnInit(): void {
    this.productService.getProducts().subscribe(
      products => this.products = products
    )
  }

  /* deleteProduct(product : Product) {
    let idx = this.products.indexOf(product);
    if(idx !== -1) {
      this.products.splice(idx,1);
    }
  } */

  deleteProduct(product:Product) {
    this.productService.deleteProduct(product);
    //after deleting this line updates the products array
    //this.products = this.productService.getProducts(); 
    this.productService.getProducts().subscribe(
      products => this.products = products
    )   
  }
}
