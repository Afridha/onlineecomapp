import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  name : string = 'Hexaware';
  city : string = 'Chennai';
  phonenumber : number = 9876543210;
  constructor() { }

  ngOnInit(): void {
  }

}
