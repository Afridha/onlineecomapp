import { Component, OnInit } from '@angular/core';
import { Customer } from '../models/customer';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  customer : Customer =new Customer();
  formSubmitted = false;
  constructor(private regService : RegistrationService) { }

  ngOnInit(): void {
  }
  displayCustomerDetails(customer : Customer)
  {
    this.regService.displayCustomerDetails(customer);
  }
}
